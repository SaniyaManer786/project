<?php
session_start();

// Connect to the database
$db = new mysqli('localhost', 'root', '', 'smarttrack');

// Check database connection
if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

// SCHEDULE REMINDER
if (isset($_POST['schedule_reminder'])) {
    $equipment_name = $_POST['equipment_name'];
    $maintenance_work = $_POST['maintenance_work'];
    $date_time = $_POST['date_time'];

    // Prepare and bind the query
    $stmt = $db->prepare("INSERT INTO reminders (equipment_name, maintenance_work, date_time) VALUES ($EquipmentName,$MaintenanceName,$Date,$Time)");
    $stmt->bind_param("sss", $equipment_name, $maintenance_work, $date_time);

    // Execute the query
    if ($stmt->execute()) {
        $reminder_id = $db->insert_id;
        $notification_time = date('Y-m-d H:i:s', strtotime('-1 hour', strtotime($date_time)));
        $stmt = $db->prepare("INSERT INTO notifications (reminder_id, notification_time) VALUES ($reminder_id, $notification_time)");
        $stmt->bind_param("is", $reminder_id, $notification_time);
        if ($stmt->execute()) {
            $_SESSION['success'] = "Reminder scheduled successfully";
            header('location: index.php');
        } else {
            echo "Error: " . $stmt->error;
        }
    } else {
        echo "Error: " . $stmt->error;
    }
}
?>